
import UIKit
import XCTest

class SwiftrisTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        
    }
    
    override func tearDown() {
        
        super.tearDown()
    }
    
    func testExample() {
        
        XCTAssert(true, "Pass")
    }
    
    func testPerformanceExample() {
        
        self.measure() {
            
        }
    }
    
}
